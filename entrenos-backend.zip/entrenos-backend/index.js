index.js
const express = require('express');
const cors = require('cors');
const { Configuration, OpenAIApi } = require('openai');

const app = express();
app.use(cors());
app.use(express.json());

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

if (!OPENAI_API_KEY) {
  console.error('ERROR: Falta la variable de entorno OPENAI_API_KEY');
  process.exit(1);
}

const configuration = new Configuration({
  apiKey: OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

app.post('/api/generar-entreno', async (req, res) => {
  const { edad, disciplina, experiencia, diasDisponibles, objetivo } = req.body;

  if (!edad || !disciplina || !experiencia || !diasDisponibles || !objetivo) {
    return res.status(400).json({ error: 'Faltan datos en la petición' });
  }

  try {
    const prompt = `
Eres un entrenador experto en ciclismo, running y natación.
Crea un plan semanal personalizado con estos datos:

Edad: ${edad}
Disciplina: ${disciplina}
Experiencia: ${experiencia}
Días disponibles: ${diasDisponibles.join(', ')}
Objetivo: ${objetivo}

Genera un plan detallado día a día.
    `;

    const completion = await openai.createChatCompletion({
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 800,
      temperature: 0.7,
    });

    const plan = completion.data.choices[0].message.content;

    res.json({ plan });
  } catch (error) {
    console.error('Error OpenAI:', error.response?.data || error.message);
    res.status(500).json({ error: 'Error generando plan' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Servidor escuchando en puerto ${port}`);
});
